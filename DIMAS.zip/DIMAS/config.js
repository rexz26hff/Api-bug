module.exports = {
  Token: "7570867091:AAFxcfLk0QDlgRqL0T84-shSmYqtLdnMXcM",
  owner: "7775991185"
};